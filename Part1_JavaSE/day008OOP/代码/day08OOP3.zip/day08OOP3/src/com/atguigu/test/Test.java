package com.atguigu.test;

import com.atguigu.fenzhuang.Dog;

public class Test {
    public static double returnValue(){

        return 10;

    }
    //jvm
    public static void main(String[] args) {
        Dog dog = new Dog();

        dog.sex = '母';

        dog.getAge();


    }
    public static void  sum(double d1,int i1){

    }
}
