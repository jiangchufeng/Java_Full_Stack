package com.atguigu.fenzhuang;

public class Dog {
    //昵称
    String nickName;

    private int age;

    public char sex;

    protected String color;


    public void getAge(){
        System.out.println(age);

    }

}
